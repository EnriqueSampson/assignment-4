package org.launchcode.javawebdevtechjobspersistent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaWebDevTechjobsPersistentApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaWebDevTechjobsPersistentApplication.class, args);
	}

}
